<?php 
include "db_connect.php"; 

session_start();
if(isset($_SESSION['username'])){
    header("Location: user/home.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Brngy. Ermita Court Reservation</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary-color: #5d9cec;
            --secondary-color: #4a89dc;
            --accent-color: #48cfad;
            --dark-bg: #2c3e50;
            --card-bg: #34495e;
            --light-bg: #ecf0f1;
            --text-primary: #ffffff;
            --text-secondary: #bdc3c7;
            --text-dark: #2c3e50;
            --success: #48cfad;
            --glass-bg: rgba(255, 255, 255, 0.08);
            --shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
            --border-color: rgba(255, 255, 255, 0.15);
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #2c3e50 0%, #34495e 50%, #2c3e50 100%);
            color: var(--text-primary);
            line-height: 1.6;
            overflow-x: hidden;
        }

        /* Navigation */
        .navbar {
            position: fixed;
            top: 0;
            width: 100%;
            background: var(--glass-bg);
            backdrop-filter: blur(20px);
            border-bottom: 1px solid var(--border-color);
            padding: 1rem 0;
            z-index: 1000;
            transition: all 0.3s ease;
        }

        .navbar.scrolled {
            background: rgba(44, 62, 80, 0.95);
            backdrop-filter: blur(30px);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }

        .nav-container {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 2rem;
        }

        .logo {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--text-primary);
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.3s ease;
        }

        .logo i {
            color: var(--primary-color);
            font-size: 1.8rem;
        }

        .logo:hover {
            transform: translateY(-2px);
        }

        .nav-links {
            display: flex;
            list-style: none;
            gap: 2rem;
            align-items: center;
        }

        .nav-links a {
            color: var(--text-primary);
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
            position: relative;
            padding: 0.5rem 0;
        }

        .nav-links a::after {
            content: '';
            position: absolute;
            width: 0;
            height: 2px;
            bottom: 0;
            left: 0;
            background: var(--primary-color);
            transition: width 0.3s ease;
        }

        .nav-links a:hover {
            color: var(--primary-color);
        }

        .nav-links a:hover::after {
            width: 100%;
        }

        .login-btn {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border: none;
            padding: 0.7rem 1.8rem;
            border-radius: 25px;
            color: white;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(93, 156, 236, 0.3);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .login-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(93, 156, 236, 0.4);
        }

        /* Hero Section */
        .hero {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            background: linear-gradient(135deg, rgba(44, 62, 80, 0.9), rgba(52, 73, 94, 0.8)),
                        url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 1000"><defs><pattern id="basketball" patternUnits="userSpaceOnUse" width="100" height="100"><circle cx="50" cy="50" r="35" fill="none" stroke="rgba(93,156,236,0.08)" stroke-width="2"/><path d="M15 50 L85 50 M50 15 L50 85" stroke="rgba(93,156,236,0.08)" stroke-width="2"/></pattern></defs><rect width="100%" height="100%" fill="url(%23basketball)"/></svg>') center/cover;
            position: relative;
            padding-top: 80px;
        }

        .hero-content {
            position: relative;
            z-index: 2;
            max-width: 800px;
            padding: 2rem;
        }

        .hero h1 {
            font-size: 3.5rem;
            font-weight: 800;
            margin-bottom: 1rem;
            color: var(--text-primary);
            animation: fadeInUp 1s ease;
            text-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
        }

        .hero h1::after {
            content: '';
            display: block;
            width: 100px;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-color), var(--accent-color));
            margin: 1rem auto;
            border-radius: 2px;
        }

        .hero p {
            font-size: 1.3rem;
            color: var(--text-secondary);
            margin-bottom: 2.5rem;
            animation: fadeInUp 1s ease 0.2s both;
        }

        .cta-buttons {
            display: flex;
            gap: 1rem;
            justify-content: center;
            flex-wrap: wrap;
            animation: fadeInUp 1s ease 0.4s both;
        }

        .cta-btn {
            padding: 1rem 2rem;
            border-radius: 30px;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }

        .cta-primary {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            box-shadow: 0 4px 15px rgba(93, 156, 236, 0.3);
        }

        .cta-primary:hover {
            box-shadow: 0 6px 20px rgba(93, 156, 236, 0.4);
        }

        .cta-secondary {
            background: transparent;
            color: var(--text-primary);
            border: 2px solid var(--primary-color);
        }

        .cta-secondary:hover {
            background: var(--primary-color);
            color: white;
        }

        .cta-btn:hover {
            transform: translateY(-3px);
        }

        /* Court Gallery Section */
        .court-section {
            padding: 100px 0;
            background: linear-gradient(180deg, var(--dark-bg), var(--card-bg));
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 2rem;
        }

        .section-title {
            text-align: center;
            font-size: 2.5rem;
            margin-bottom: 1rem;
            color: var(--text-primary);
            font-weight: 700;
        }

        .section-subtitle {
            text-align: center;
            color: var(--text-secondary);
            margin-bottom: 3rem;
            font-size: 1.1rem;
        }

        .gallery-container {
            position: relative;
            max-width: 900px;
            margin: 0 auto;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: var(--shadow);
            border: 1px solid var(--border-color);
        }

        .gallery-slider {
            position: relative;
            width: 100%;
            height: 500px;
        }

        .slide {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            opacity: 0;
            transition: all 0.6s ease;
            background-size: cover;
            background-position: center;
        }

        .slide.active {
            opacity: 1;
        }

        .slide::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            height: 100px;
            background: linear-gradient(to top, rgba(0,0,0,0.7), transparent);
        }

        .slide1 { background-image: linear-gradient(rgba(0,0,0,0.2), rgba(0,0,0,0.2)), url('assets/imgs/guada_court1.jpg'), url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 500"><rect width="100%" height="100%" fill="%2348cfad"/><rect x="50" y="50" width="700" height="400" fill="none" stroke="%23fff" stroke-width="4"/><circle cx="400" cy="250" r="80" fill="none" stroke="%23fff" stroke-width="3"/><rect x="50" y="180" width="120" height="140" fill="none" stroke="%23fff" stroke-width="3"/><rect x="630" y="180" width="120" height="140" fill="none" stroke="%23fff" stroke-width="3"/><text x="400" y="480" text-anchor="middle" fill="white" font-size="20" font-weight="bold">Basketball Court 1</text></svg>'); }
        
        .slide2 { background-image: linear-gradient(rgba(0,0,0,0.2), rgba(0,0,0,0.2)), url('assets/imgs/guada_court2.jpg'), url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 500"><rect width="100%" height="100%" fill="%235d9cec"/><rect x="50" y="50" width="700" height="400" fill="none" stroke="%23fff" stroke-width="4"/><circle cx="400" cy="250" r="80" fill="none" stroke="%23fff" stroke-width="3"/><rect x="50" y="180" width="120" height="140" fill="none" stroke="%23fff" stroke-width="3"/><rect x="630" y="180" width="120" height="140" fill="none" stroke="%23fff" stroke-width="3"/><text x="400" y="480" text-anchor="middle" fill="white" font-size="20" font-weight="bold">Basketball Court 2</text></svg>'); }
        
        .slide3 { background-image: linear-gradient(rgba(0,0,0,0.2), rgba(0,0,0,0.2)), url('assets/imgs/guada_court3.jpg'), url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 500"><rect width="100%" height="100%" fill="%234a89dc"/><rect x="50" y="50" width="700" height="400" fill="none" stroke="%23fff" stroke-width="4"/><circle cx="400" cy="250" r="80" fill="none" stroke="%23fff" stroke-width="3"/><rect x="50" y="180" width="120" height="140" fill="none" stroke="%23fff" stroke-width="3"/><rect x="630" y="180" width="120" height="140" fill="none" stroke="%23fff" stroke-width="3"/><text x="400" y="480" text-anchor="middle" fill="white" font-size="20" font-weight="bold">Basketball Court 3</text></svg>'); }

        .gallery-nav {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            background: rgba(93, 156, 236, 0.9);
            backdrop-filter: blur(10px);
            border: none;
            color: white;
            font-size: 1.3rem;
            width: 45px;
            height: 45px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            cursor: pointer;
            transition: all 0.3s ease;
            z-index: 10;
        }

        .gallery-nav:hover {
            background: var(--primary-color);
            transform: translateY(-50%) scale(1.15);
            box-shadow: 0 4px 15px rgba(93, 156, 236, 0.5);
        }

        .prev { left: 20px; }
        .next { right: 20px; }

        .gallery-dots {
            display: flex;
            justify-content: center;
            gap: 0.8rem;
            margin-top: 2rem;
        }

        .dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.3);
            cursor: pointer;
            transition: all 0.3s ease;
            border: 2px solid transparent;
        }

        .dot:hover {
            background: rgba(255, 255, 255, 0.5);
        }

        .dot.active {
            background: var(--primary-color);
            transform: scale(1.3);
            border-color: var(--primary-color);
        }

        /* Login Modal */
        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);
            backdrop-filter: blur(8px);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 2000;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease;
        }

        .modal-overlay.active {
            opacity: 1;
            visibility: visible;
        }

        .modal {
            background: var(--card-bg);
            backdrop-filter: blur(20px);
            border: 1px solid var(--border-color);
            padding: 2.5rem;
            border-radius: 20px;
            max-width: 420px;
            width: 90%;
            transform: translateY(-50px);
            transition: all 0.3s ease;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
        }

        .modal-overlay.active .modal {
            transform: translateY(0);
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
        }

        .modal h2 {
            font-size: 1.8rem;
            color: var(--text-primary);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .modal h2 i {
            color: var(--primary-color);
        }

        .close-btn {
            background: rgba(255, 255, 255, 0.1);
            border: none;
            color: var(--text-primary);
            font-size: 1.3rem;
            cursor: pointer;
            width: 35px;
            height: 35px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: all 0.3s ease;
        }

        .close-btn:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: rotate(90deg);
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            color: var(--text-secondary);
            font-weight: 500;
            font-size: 0.9rem;
        }

        .form-group input {
            width: 100%;
            padding: 1rem 1.2rem;
            background: rgba(255, 255, 255, 0.08);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            color: var(--text-primary);
            font-size: 1rem;
            transition: all 0.3s ease;
        }

        .form-group input:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(93, 156, 236, 0.1);
            background: rgba(255, 255, 255, 0.1);
        }

        .form-group input::placeholder {
            color: var(--text-secondary);
        }

        .submit-btn {
            width: 100%;
            padding: 1rem;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border: none;
            border-radius: 12px;
            color: white;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }

        .submit-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(93, 156, 236, 0.4);
        }

        .register-link {
            text-align: center;
            color: var(--text-secondary);
            font-size: 0.95rem;
        }

        .register-link a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .register-link a:hover {
            color: var(--accent-color);
            text-decoration: underline;
        }

        /* Mobile Menu */
        .mobile-menu-toggle {
            display: none;
            background: none;
            border: none;
            color: var(--text-primary);
            font-size: 1.5rem;
            cursor: pointer;
            padding: 0.5rem;
        }

        /* Animations */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-15px); }
        }

        .floating {
            animation: float 5s ease-in-out infinite;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .nav-links {
                display: none;
            }

            .mobile-menu-toggle {
                display: block;
            }

            .hero h1 {
                font-size: 2.5rem;
            }

            .hero p {
                font-size: 1.1rem;
            }

            .cta-buttons {
                flex-direction: column;
                align-items: center;
            }

            .gallery-slider {
                height: 350px;
            }

            .section-title {
                font-size: 2rem;
            }

            .modal {
                padding: 2rem;
            }
        }

        @media (max-width: 480px) {
            .nav-container {
                padding: 0 1rem;
            }

            .hero-content {
                padding: 1rem;
            }

            .hero h1 {
                font-size: 2rem;
            }

            .container {
                padding: 0 1rem;
            }

            .gallery-slider {
                height: 280px;
            }

            .gallery-nav {
                width: 38px;
                height: 38px;
                font-size: 1.1rem;
            }

            .prev { left: 10px; }
            .next { right: 10px; }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar" id="navbar">
        <div class="nav-container">
            <a href="#home" class="logo">
                <i class="fas fa-basketball-ball"></i>
                <span>Barangay Ermita</span>
            </a>
            <ul class="nav-links">
                <li><a href="login.php#top">Home</a></li>
                <li><a href="user/booking.php">Book Now</a></li>
                <li><a href="view_book.php">View Bookings</a></li>
            </ul>
            <button class="login-btn" id="loginBtn">
                <i class="fas fa-sign-in-alt"></i> Login
            </button>
            <button class="mobile-menu-toggle">
                <i class="fas fa-bars"></i>
            </button>
        </div>
    </nav>

    <!-- Hero Section -->
    <section id="home" class="hero">
        <div class="hero-content">
            <h1 class="floating">Barangay Ermita</h1>
            <p>We serve like you deserved</p>
            <div class="cta-buttons">
                <a href="#courts" class="cta-btn cta-primary">
                    <i class="fas fa-eye"></i> View Courts
                </a>
                <a href="#" class="cta-btn cta-secondary" id="bookNowBtn">
                    <i class="fas fa-calendar-plus"></i> Book Now
                </a>
            </div>
        </div>
    </section>

    <!-- Court Gallery Section -->
    <section id="courts" class="court-section">
        <div class="container">
            <h2 class="section-title">Our Courts</h2>
            <p class="section-subtitle">Quality basketball courts for the community</p>
            <div class="gallery-container">
                <div class="gallery-slider">
                    <div class="slide slide1 active"></div>
                    <div class="slide slide2"></div>
                    <div class="slide slide3"></div>
                </div>
                <button class="gallery-nav prev" id="prevBtn">
                    <i class="fas fa-chevron-left"></i>
                </button>
                <button class="gallery-nav next" id="nextBtn">
                    <i class="fas fa-chevron-right"></i>
                </button>
            </div>
            <div class="gallery-dots">
                <span class="dot active" data-slide="0"></span>
                <span class="dot" data-slide="1"></span>
                <span class="dot" data-slide="2"></span>
            </div>
        </div>
    </section>

    <!-- Login Modal -->
    <div class="modal-overlay" id="loginModal">
        <div class="modal">
            <div class="modal-header">
                <h2><i class="fas fa-sign-in-alt"></i> Login</h2>
                <button class="close-btn" id="closeModal">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <form action="login.php" method="post">
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" placeholder="Enter your username" required>
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" placeholder="Enter your password" required>
                </div>
                <button type="submit" class="submit-btn">
                    <i class="fas fa-sign-in-alt"></i> Login
                </button>
            </form>
            <p class="register-link">
                Don't have an account? <a href="user/register.php">Register here</a>
            </p>
        </div>
    </div>

    <script>
        // Navbar scroll effect
        window.addEventListener('scroll', function() {
            const navbar = document.getElementById('navbar');
            if (window.scrollY > 50) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });

        // Modal functionality
        const loginBtn = document.getElementById('loginBtn');
        const bookNowBtn = document.getElementById('bookNowBtn');
        const loginModal = document.getElementById('loginModal');
        const closeModal = document.getElementById('closeModal');

        function openModal() {
            loginModal.classList.add('active');
            document.body.style.overflow = 'hidden';
        }

        function closeModalFunc() {
            loginModal.classList.remove('active');
            document.body.style.overflow = 'auto';
        }

        loginBtn.addEventListener('click', openModal);
        bookNowBtn.addEventListener('click', function(e) {
            e.preventDefault();
            openModal();
        });
        closeModal.addEventListener('click', closeModalFunc);

        loginModal.addEventListener('click', function(e) {
            if (e.target === loginModal) {
                closeModalFunc();
            }
        });

        // Escape key to close modal
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && loginModal.classList.contains('active')) {
                closeModalFunc();
            }
        });

        // Gallery slider
        const slides = document.querySelectorAll('.slide');
        const dots = document.querySelectorAll('.dot');
        const prevBtn = document.getElementById('prevBtn');
        const nextBtn = document.getElementById('nextBtn');

        let currentSlide = 0;
        let slideInterval;

        function showSlide(index) {
            // Remove active class from all slides and dots
            slides.forEach(slide => slide.classList.remove('active'));
            dots.forEach(dot => dot.classList.remove('active'));

            // Handle wrap around
            if (index >= slides.length) currentSlide = 0;
            else if (index < 0) currentSlide = slides.length - 1;
            else currentSlide = index;

            // Add active class to current slide and dot
            slides[currentSlide].classList.add('active');
            dots[currentSlide].classList.add('active');
        }

        function nextSlide() {
            showSlide(currentSlide + 1);
        }

        function prevSlide() {
            showSlide(currentSlide - 1);
        }

        // Auto-play functionality
        function startSlideshow() {
            slideInterval = setInterval(nextSlide, 4000);
        }

        function stopSlideshow() {
            clearInterval(slideInterval);
        }

        // Event listeners
        nextBtn.addEventListener('click', function() {
            stopSlideshow();
            nextSlide();
            startSlideshow();
        });

        prevBtn.addEventListener('click', function() {
            stopSlideshow();
            prevSlide();
            startSlideshow();
        });

        // Dot navigation
        dots.forEach((dot, index) => {
            dot.addEventListener('click', function() {
                stopSlideshow();
                showSlide(index);
                startSlideshow();
            });
        });

        // Pause slideshow on hover
        const galleryContainer = document.querySelector('.gallery-container');
        galleryContainer.addEventListener('mouseenter', stopSlideshow);
        galleryContainer.addEventListener('mouseleave', startSlideshow);

        // Smooth scrolling for navigation links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });

        // Initialize slideshow
        document.addEventListener('DOMContentLoaded', function() {
            startSlideshow();
        });

        // Add loading animation for images
        window.addEventListener('load', function() {
            document.body.classList.add('loaded');
        });
    </script>
</body>
</html>