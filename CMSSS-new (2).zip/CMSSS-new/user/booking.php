<?php
session_start();
include "../db_connect.php";

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$conn->set_charset('utf8mb4');

if (!isset($_SESSION['username'])) {
    echo "<script>alert('You need to log in first'); window.location.href='../index.php';</script>";
    exit();
}

$username = $_SESSION['username'];

$user_sql = "SELECT email, phonenumber, fullname FROM users WHERE username = ?";
$user_stmt = $conn->prepare($user_sql);
$user_stmt->bind_param("s", $username);
$user_stmt->execute();
$user_result = $user_stmt->get_result();

if ($user_result->num_rows === 0) {
    echo "<script>alert('User record not found.'); window.location.href='../index.php';</script>";
    exit();
}

$user_row = $user_result->fetch_assoc();
$email = $user_row['email'];
$phone = $user_row['phonenumber'];
$stored_fullname = $user_row['fullname'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Book Court</title>
  <link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.15/index.global.min.css" rel="stylesheet" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    :root {
      --primary-color: #5d9cec;
      --secondary-color: #4a89dc;
      --accent-color: #48cfad;
      --dark-bg: #2c3e50;
      --card-bg: #34495e;
      --text-primary: #ffffff;
      --text-secondary: #bdc3c7;
      --glass-bg: rgba(255, 255, 255, 0.08);
      --shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
      --border-color: rgba(255, 255, 255, 0.15);
    }

    body {
      background: linear-gradient(135deg, #2c3e50 0%, #34495e 50%, #2c3e50 100%);
      color: var(--text-primary);
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      min-height: 100vh;
      padding: 20px;
    }

    .page-header {
      max-width: 1100px;
      margin: 0 auto 20px;
      display: flex;
      align-items: center;
      gap: 20px;
    }

    .back-link {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      color: var(--text-primary);
      text-decoration: none;
      padding: 10px 20px;
      background: var(--card-bg);
      border-radius: 10px;
      border: 1px solid var(--border-color);
      transition: all 0.3s ease;
      font-weight: 500;
    }

    .back-link:hover {
      background: var(--primary-color);
      transform: translateX(-3px);
      box-shadow: 0 4px 15px rgba(93, 156, 236, 0.3);
    }

    .page-title {
      font-size: 2rem;
      font-weight: 700;
      color: var(--text-primary);
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .page-title i {
      color: var(--primary-color);
    }

    .calendar-container {
      max-width: 1100px;
      margin: 0 auto;
      background: var(--card-bg);
      border-radius: 16px;
      box-shadow: var(--shadow);
      padding: 20px;
      border: 1px solid var(--border-color);
    }

    #calendar {
      width: 100%;
      background: transparent;
    }

    /* FullCalendar Custom Styling */
    .fc {
      --fc-border-color: rgba(255, 255, 255, 0.1);
      --fc-button-bg-color: #5d9cec;
      --fc-button-border-color: #5d9cec;
      --fc-button-hover-bg-color: #4a89dc;
      --fc-button-hover-border-color: #4a89dc;
      --fc-button-active-bg-color: #4a89dc;
      --fc-button-active-border-color: #4a89dc;
      --fc-today-bg-color: rgba(72, 207, 173, 0.15);
    }

    .fc .fc-toolbar-title {
      color: var(--text-primary);
      font-size: 1.6rem;
      font-weight: 700;
    }

    .fc .fc-button {
      border-radius: 8px;
      padding: 8px 16px;
      font-weight: 600;
      text-transform: capitalize;
      box-shadow: 0 2px 8px rgba(93, 156, 236, 0.3);
    }

    .fc .fc-button:hover {
      box-shadow: 0 4px 12px rgba(93, 156, 236, 0.4);
    }

    .fc .fc-col-header-cell {
      background: rgba(93, 156, 236, 0.1);
      color: var(--text-primary);
      font-weight: 600;
      padding: 12px 0;
      border-color: var(--border-color);
    }

    .fc .fc-daygrid-day {
      background: rgba(255, 255, 255, 0.03);
      transition: all 0.3s ease;
      cursor: pointer;
    }

    .fc .fc-daygrid-day:hover {
      background: rgba(93, 156, 236, 0.1);
    }

    .fc .fc-daygrid-day-number {
      color: var(--text-primary);
      padding: 8px;
      font-weight: 500;
    }

    .fc .fc-daygrid-day.fc-day-today {
      background: rgba(72, 207, 173, 0.15) !important;
    }

    .fc .fc-daygrid-day.fc-day-today .fc-daygrid-day-number {
      background: var(--accent-color);
      color: white;
      border-radius: 50%;
      width: 32px;
      height: 32px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 700;
    }

    .fc-event {
      background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)) !important;
      border: none !important;
      border-radius: 6px;
      padding: 2px 6px;
      font-size: 0.85rem;
      font-weight: 600;
    }

    /* Modal Styling */
    .modal {
      display: none;
      position: fixed;
      z-index: 1000;
      inset: 0;
      background: rgba(0, 0, 0, 0.75);
      backdrop-filter: blur(8px);
      animation: fadeIn 0.3s ease;
    }

    .modal.active {
      display: flex;
      align-items: center;
      justify-content: center;
    }

    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }

    .modal-content {
      background: var(--card-bg);
      margin: 20px;
      padding: 30px;
      border-radius: 16px;
      width: 90%;
      max-width: 500px;
      box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
      border: 1px solid var(--border-color);
      animation: slideUp 0.3s ease;
    }

    @keyframes slideUp {
      from {
        opacity: 0;
        transform: translateY(30px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 25px;
    }

    .modal h2 {
      color: var(--text-primary);
      font-size: 1.8rem;
      display: flex;
      align-items: center;
      gap: 10px;
      margin: 0;
    }

    .modal h2 i {
      color: var(--primary-color);
    }

    .close {
      background: rgba(255, 255, 255, 0.1);
      border: none;
      color: var(--text-secondary);
      font-size: 1.3rem;
      cursor: pointer;
      width: 35px;
      height: 35px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
      transition: all 0.3s ease;
    }

    .close:hover {
      color: var(--primary-color);
      background: rgba(93, 156, 236, 0.15);
      transform: rotate(90deg);
    }

    .form-group {
      margin-bottom: 20px;
    }

    label {
      display: block;
      margin-bottom: 8px;
      font-weight: 600;
      color: var(--text-secondary);
      font-size: 0.9rem;
    }

    input, select {
      width: 100%;
      padding: 12px 15px;
      border-radius: 10px;
      border: 1px solid var(--border-color);
      font-size: 15px;
      background: rgba(255, 255, 255, 0.05);
      color: var(--text-primary);
      transition: all 0.3s ease;
    }

    input:focus, select:focus {
      outline: none;
      border-color: var(--primary-color);
      background: rgba(255, 255, 255, 0.08);
      box-shadow: 0 0 0 3px rgba(93, 156, 236, 0.1);
    }

    input[readonly] {
      background: rgba(255, 255, 255, 0.03);
      cursor: not-allowed;
    }

    select option {
      background: var(--card-bg);
      color: var(--text-primary);
      padding: 10px;
    }

    .booked {
      background: rgba(231, 76, 60, 0.2) !important;
      color: #e74c3c !important;
      font-weight: 700;
      position: relative;
    }

    .booked::after {
      content: ' (Booked)';
      font-size: 0.85em;
      color: #e74c3c;
    }

    button[type="submit"] {
      width: 100%;
      background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
      color: white;
      border: none;
      padding: 14px;
      border-radius: 10px;
      cursor: pointer;
      font-size: 16px;
      font-weight: 600;
      transition: all 0.3s ease;
      margin-top: 10px;
      box-shadow: 0 4px 15px rgba(93, 156, 236, 0.3);
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 10px;
    }

    button[type="submit"]:hover {
      background: linear-gradient(135deg, var(--secondary-color), var(--primary-color));
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(93, 156, 236, 0.5);
    }

    button[type="submit"]:active {
      transform: translateY(0);
    }

    /* Responsive Design */
    @media (max-width: 768px) {
      .page-header {
        flex-direction: column;
        align-items: flex-start;
        gap: 10px;
      }

      .page-title {
        font-size: 1.5rem;
      }

      .calendar-container {
        padding: 15px;
      }

      .fc .fc-toolbar {
        flex-direction: column;
        gap: 10px;
      }

      .fc .fc-toolbar-title {
        font-size: 1.3rem;
      }

      .modal-content {
        padding: 20px;
      }

      .modal h2 {
        font-size: 1.5rem;
      }
    }

    @media (max-width: 480px) {
      body {
        padding: 10px;
      }

      .back-link {
        padding: 8px 15px;
        font-size: 0.9rem;
      }

      .page-title {
        font-size: 1.3rem;
      }

      .calendar-container {
        padding: 10px;
      }

      input, select {
        padding: 10px 12px;
        font-size: 14px;
      }

      button[type="submit"] {
        padding: 12px;
        font-size: 15px;
      }
    }
  </style>
</head>
<body>
  <div class="page-header">
    <a href="home.php" class="back-link">
      <i class="fas fa-arrow-left"></i> Back to Home
    </a>
    <h1 class="page-title">
      <i class="fas fa-calendar-plus"></i>
      Book a Court
    </h1>
  </div>

  <div class="calendar-container">
    <div id="calendar"></div>
  </div>

  <!-- Modal -->
  <div id="dateModal" class="modal" aria-hidden="true">
    <div class="modal-content" role="dialog" aria-modal="true">
      <div class="modal-header">
        <h2><i class="fas fa-calendar-check"></i> Book Court</h2>
        <button class="close" title="Close">
          <i class="fas fa-times"></i>
        </button>
      </div>
      <form action="booking_process.php" method="post" id="bookingForm">
        <input type="hidden" id="dbDate" name="date" />

        <div class="form-group">
          <label for="displayDate"><i class="fas fa-calendar"></i> Date:</label>
          <input type="text" id="displayDate" readonly />
        </div>

        <div class="form-group">
          <label for="name"><i class="fas fa-user"></i> Name:</label>
          <input type="text" id="name" name="fullname" value="<?php echo htmlspecialchars($stored_fullname); ?>" required />
        </div>

        <div class="form-group">
          <label for="court"><i class="fas fa-basketball-ball"></i> Court Type:</label>
          <select id="court" name="court_type" required>
            <option value="">Select court type</option>
            <option value="Basketball">Basketball</option>
            <option value="Volleyball">Volleyball</option>
          </select>
        </div>

        <div class="form-group">
          <label for="time"><i class="fas fa-clock"></i> Time Slot:</label>
          <select id="time" name="time" required>
            <option value="">Select time slot</option>
            <option value="8AM - 9AM">8AM - 9AM</option>
            <option value="9AM - 10AM">9AM - 10AM</option>
            <option value="10AM - 11AM">10AM - 11AM</option>
            <option value="11AM - 12PM">11AM - 12PM</option>
            <option value="1PM - 2PM">1PM - 2PM</option>
            <option value="2PM - 3PM">2PM - 3PM</option>
            <option value="3PM - 4PM">3PM - 4PM</option>
            <option value="4PM - 5PM">4PM - 5PM</option>
            <option value="5PM - 6PM">5PM - 6PM</option>
            <option value="6PM - 7PM">6PM - 7PM</option>
            <option value="7PM - 8PM">7PM - 8PM</option>
            <option value="8PM - 9PM">8PM - 9PM</option>
            <option value="9PM - 10PM">9PM - 10PM</option>
          </select>
        </div>

        <button type="submit" id="submitBtn">
          <i class="fas fa-check-circle"></i> Confirm Booking
        </button>
      </form>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.15/index.global.min.js"></script>
  <script>
    document.addEventListener('DOMContentLoaded', function () {
      const calendarEl = document.getElementById('calendar');
      const modal = document.getElementById('dateModal');
      const closeBtn = document.querySelector('.close');
      const displayDate = document.getElementById('displayDate');
      const dbDate = document.getElementById('dbDate');
      const timeSelect = document.getElementById('time');
      const bookingForm = document.getElementById('bookingForm');

      const calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        headerToolbar: {
          left: 'prev,next today',
          center: 'title',
          right: 'dayGridMonth,dayGridWeek'
        },
        events: 'fetch_bookings.php',

        dateClick: function (info) {
          dbDate.value = info.dateStr;
          const dateObj = new Date(info.dateStr);
          displayDate.value = dateObj.toLocaleDateString(undefined, {
            weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'
          });

          // Reset all time slots
          for (let i = 0; i < timeSelect.options.length; i++) {
            const opt = timeSelect.options[i];
            opt.classList.remove('booked');
            opt.disabled = false;
          }

          // Fetch booked times for this date
          fetch('fetch_bookings.php?date=' + encodeURIComponent(info.dateStr))
            .then(res => {
              if (!res.ok) throw new Error('Network response was not ok');
              return res.json();
            })
            .then(rows => {
              rows.forEach(r => {
                for (let i = 0; i < timeSelect.options.length; i++) {
                  const opt = timeSelect.options[i];
                  if (opt.value === r.time) {
                    opt.classList.add('booked');
                    opt.disabled = true;
                  }
                }
              });
            })
            .catch(err => {
              console.error('Failed to load booked times:', err);
            });

          modal.classList.add('active');
          modal.style.display = 'flex';
        }
      });

      calendar.render();

      // Close modal
      closeBtn.onclick = () => {
        modal.classList.remove('active');
        setTimeout(() => modal.style.display = 'none', 300);
      };
      
      window.onclick = (e) => {
        if (e.target === modal) {
          modal.classList.remove('active');
          setTimeout(() => modal.style.display = 'none', 300);
        }
      };

      // Form validation
      bookingForm.addEventListener('submit', function (e) {
        const selected = timeSelect.options[timeSelect.selectedIndex];
        if (!selected || selected.value === '') {
          e.preventDefault();
          alert('Please choose a time slot.');
          return;
        }
        if (selected.classList.contains('booked')) {
          e.preventDefault();
          alert('That time slot is already booked. Please choose another time.');
          return;
        }
      });
    });
  </script>
</body>
</html>