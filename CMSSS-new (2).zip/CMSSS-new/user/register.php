<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary-color: #5d9cec;
            --secondary-color: #4a89dc;
            --accent-color: #48cfad;
            --dark-bg: #2c3e50;
            --card-bg: #34495e;
            --text-primary: #ffffff;
            --text-secondary: #bdc3c7;
            --glass-bg: rgba(255, 255, 255, 0.08);
            --shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
            --border-color: rgba(255, 255, 255, 0.15);
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #2c3e50 0%, #34495e 50%, #2c3e50 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
            position: relative;
            overflow: hidden;
        }

        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 1000"><defs><pattern id="basketball" patternUnits="userSpaceOnUse" width="100" height="100"><circle cx="50" cy="50" r="35" fill="none" stroke="rgba(93,156,236,0.05)" stroke-width="2"/><path d="M15 50 L85 50 M50 15 L50 85" stroke="rgba(93,156,236,0.05)" stroke-width="2"/></pattern></defs><rect width="100%" height="100%" fill="url(%23basketball)"/></svg>') center/cover;
            opacity: 0.3;
        }

        .form-container {
            background: var(--card-bg);
            backdrop-filter: blur(20px);
            border-radius: 20px;
            box-shadow: var(--shadow);
            overflow: hidden;
            max-width: 480px;
            width: 100%;
            position: relative;
            border: 1px solid var(--border-color);
            animation: slideUp 0.6s ease;
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .form-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-color), var(--accent-color), var(--primary-color));
        }

        .container-inside {
            padding: 50px 40px;
        }

        .header-icon {
            text-align: center;
            margin-bottom: 20px;
        }

        .header-icon i {
            font-size: 48px;
            color: var(--primary-color);
            animation: float 3s ease-in-out infinite;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-10px); }
        }

        h2 {
            color: var(--text-primary);
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 10px;
            text-align: center;
            letter-spacing: -0.5px;
        }

        .subtitle {
            color: var(--text-secondary);
            text-align: center;
            margin-bottom: 35px;
            font-size: 14px;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 18px;
        }

        .input-group {
            position: relative;
        }

        .input-group i {
            position: absolute;
            left: 18px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-secondary);
            font-size: 16px;
            transition: all 0.3s ease;
        }

        input[type="text"],
        input[type="email"],
        input[type="password"] {
            width: 100%;
            padding: 15px 20px 15px 48px;
            border: 1px solid var(--border-color);
            border-radius: 12px;
            font-size: 15px;
            transition: all 0.3s ease;
            background: rgba(255, 255, 255, 0.05);
            color: var(--text-primary);
        }

        input[type="text"]:focus,
        input[type="email"]:focus,
        input[type="password"]:focus {
            outline: none;
            border-color: var(--primary-color);
            background: rgba(255, 255, 255, 0.08);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(93, 156, 236, 0.2);
        }

        input[type="text"]:focus + i,
        input[type="email"]:focus + i,
        input[type="password"]:focus + i {
            color: var(--primary-color);
        }

        input::placeholder {
            color: var(--text-secondary);
        }

        input[type="submit"] {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            border: none;
            padding: 16px;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-top: 10px;
            text-transform: uppercase;
            letter-spacing: 1px;
            box-shadow: 0 5px 20px rgba(93, 156, 236, 0.3);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        input[type="submit"]::before {
            content: '\f234';
            font-family: 'Font Awesome 6 Free';
            font-weight: 900;
        }

        input[type="submit"]:hover {
            background: linear-gradient(135deg, var(--secondary-color), var(--primary-color));
            transform: translateY(-2px);
            box-shadow: 0 10px 30px rgba(93, 156, 236, 0.5);
        }

        input[type="submit"]:active {
            transform: translateY(0);
        }

        p {
            text-align: center;
            margin-top: 25px;
            color: var(--text-secondary);
            font-size: 14px;
        }

        a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
            position: relative;
        }

        a::after {
            content: '';
            position: absolute;
            bottom: -2px;
            left: 0;
            width: 0;
            height: 2px;
            background: var(--primary-color);
            transition: width 0.3s ease;
        }

        a:hover {
            color: var(--accent-color);
        }

        a:hover::after {
            width: 100%;
        }

        .message {
            padding: 12px 16px;
            border-radius: 10px;
            margin-bottom: 20px;
            text-align: center;
            font-size: 14px;
            font-weight: 500;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        .success {
            background: rgba(72, 207, 173, 0.15);
            color: var(--accent-color);
            border: 1px solid rgba(72, 207, 173, 0.3);
        }

        .success::before {
            content: '\f058';
            font-family: 'Font Awesome 6 Free';
            font-weight: 900;
            font-size: 18px;
        }

        .error {
            background: rgba(231, 76, 60, 0.15);
            color: #e74c3c;
            border: 1px solid rgba(231, 76, 60, 0.3);
        }

        .error::before {
            content: '\f06a';
            font-family: 'Font Awesome 6 Free';
            font-weight: 900;
            font-size: 18px;
        }

        .password-strength {
            margin-top: -10px;
            font-size: 12px;
            color: var(--text-secondary);
            display: none;
        }

        .strength-bar {
            height: 3px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 2px;
            margin-top: 5px;
            overflow: hidden;
        }

        .strength-fill {
            height: 100%;
            width: 0%;
            transition: all 0.3s ease;
            border-radius: 2px;
        }

        .strength-weak { background: #e74c3c; width: 33%; }
        .strength-medium { background: #f39c12; width: 66%; }
        .strength-strong { background: var(--accent-color); width: 100%; }

        @media (max-width: 480px) {
            .container-inside {
                padding: 40px 30px;
            }

            h2 {
                font-size: 28px;
            }

            .header-icon i {
                font-size: 40px;
            }

            input[type="text"],
            input[type="email"],
            input[type="password"] {
                padding: 13px 18px 13px 45px;
            }

            .input-group i {
                left: 15px;
                font-size: 14px;
            }
        }

        /* Loading animation */
        .loading {
            display: none;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }

        .loading::after {
            content: '';
            width: 30px;
            height: 30px;
            border: 3px solid rgba(255, 255, 255, 0.1);
            border-top-color: var(--primary-color);
            border-radius: 50%;
            animation: spin 0.8s linear infinite;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <div class="form-container">
        <div class="container-inside">
            <div class="header-icon">
                <i class="fas fa-user-plus"></i>
            </div>
            <h2>Create Account</h2>
            <p class="subtitle">Join us to book your court today</p>
            
            <!-- PHP messages would appear here -->
            <!-- <div class="message success">Account created successfully!</div> -->
            <!-- <div class="message error">Password does not match</div> -->
            
            <form action="register.php" method="POST" id="registerForm">
                <div class="input-group">
                    <input type="text" name="username" id="username" placeholder="Username" required>
                    <i class="fas fa-user"></i>
                </div>

                <div class="input-group">
                    <input type="text" name="fullname" id="fullname" placeholder="Full Name" required>
                    <i class="fas fa-id-card"></i>
                </div>

                <div class="input-group">
                    <input type="email" name="email" id="email" placeholder="Email Address" required>
                    <i class="fas fa-envelope"></i>
                </div>

                <div class="input-group">
                    <input type="text" name="phonenumber" id="phonenumber" placeholder="Phone Number" required>
                    <i class="fas fa-phone"></i>
                </div>

                <div class="input-group">
                    <input type="password" name="password" id="password" placeholder="Password" required>
                    <i class="fas fa-lock"></i>
                </div>

                <div class="password-strength" id="passwordStrength">
                    <div class="strength-bar">
                        <div class="strength-fill" id="strengthFill"></div>
                    </div>
                    <span id="strengthText"></span>
                </div>

                <div class="input-group">
                    <input type="password" name="confirmPassword" id="confirmPassword" placeholder="Confirm Password" required>
                    <i class="fas fa-lock"></i>
                </div>

                <input type="submit" value="Create Account">
                <p>Already have an account? <a href="../index.php"><i class="fas fa-sign-in-alt"></i> Log In</a></p>
            </form>
        </div>
    </div>

    <script>
        // Password strength checker
        const passwordInput = document.getElementById('password');
        const strengthIndicator = document.getElementById('passwordStrength');
        const strengthFill = document.getElementById('strengthFill');
        const strengthText = document.getElementById('strengthText');

        passwordInput.addEventListener('input', function() {
            const password = this.value;
            
            if (password.length === 0) {
                strengthIndicator.style.display = 'none';
                return;
            }

            strengthIndicator.style.display = 'block';
            
            let strength = 0;
            if (password.length >= 8) strength++;
            if (password.match(/[a-z]/) && password.match(/[A-Z]/)) strength++;
            if (password.match(/[0-9]/)) strength++;
            if (password.match(/[^a-zA-Z0-9]/)) strength++;

            strengthFill.className = 'strength-fill';
            
            if (strength <= 1) {
                strengthFill.classList.add('strength-weak');
                strengthText.textContent = 'Weak password';
                strengthText.style.color = '#e74c3c';
            } else if (strength <= 3) {
                strengthFill.classList.add('strength-medium');
                strengthText.textContent = 'Medium password';
                strengthText.style.color = '#f39c12';
            } else {
                strengthFill.classList.add('strength-strong');
                strengthText.textContent = 'Strong password';
                strengthText.style.color = '#48cfad';
            }
        });

        // Form validation
        const form = document.getElementById('registerForm');
        const confirmPassword = document.getElementById('confirmPassword');

        form.addEventListener('submit', function(e) {
            if (passwordInput.value !== confirmPassword.value) {
                e.preventDefault();
                alert('Passwords do not match!');
                confirmPassword.focus();
            }
        });

        // Phone number formatting (optional)
        const phoneInput = document.getElementById('phonenumber');
        phoneInput.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            e.target.value = value;
        });
    </script>
</body>
</html>