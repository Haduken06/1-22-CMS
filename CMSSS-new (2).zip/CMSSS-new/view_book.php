<?php
include "db_connect.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>View Bookings</title>
  <link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.15/index.global.min.css" rel="stylesheet" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    :root {
      --primary-color: #5d9cec;
      --secondary-color: #4a89dc;
      --accent-color: #48cfad;
      --dark-bg: #2c3e50;
      --card-bg: #34495e;
      --light-bg: #ecf0f1;
      --text-primary: #ffffff;
      --text-secondary: #bdc3c7;
      --text-dark: #2c3e50;
      --success: #48cfad;
      --glass-bg: rgba(255, 255, 255, 0.08);
      --shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
      --border-color: rgba(255, 255, 255, 0.15);
    }

    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: linear-gradient(135deg, #2c3e50 0%, #34495e 50%, #2c3e50 100%);
      margin: 0;
      padding: 0;
      min-height: 100vh;
    }

    header {
      background: linear-gradient(135deg, var(--dark-bg), var(--card-bg));
      color: var(--text-primary);
      padding: 1.5rem 2rem;
      text-align: center;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
      border-bottom: 1px solid var(--border-color);
      position: relative;
    }

    header h1 {
      font-size: 2rem;
      font-weight: 700;
      margin: 0;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 0.75rem;
    }

    header h1 i {
      color: var(--primary-color);
      font-size: 1.8rem;
    }

    .anchor {
      position: absolute;
      left: 2rem;
      top: 50%;
      transform: translateY(-50%);
      background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
      text-decoration: none;
      padding: 0.7rem 1rem;
      border-radius: 12px;
      color: white;
      font-weight: bold;
      font-size: 1.1rem;
      transition: all 0.3s ease;
      box-shadow: 0 4px 15px rgba(93, 156, 236, 0.3);
      display: inline-flex;
      align-items: center;
      gap: 0.5rem;
    }

    .anchor:hover {
      transform: translateY(-50%) translateY(-2px);
      box-shadow: 0 6px 20px rgba(93, 156, 236, 0.4);
    }

    .calendar-container {
      max-width: 1100px;
      margin: 2rem auto;
      padding: 0 1.5rem;
    }

    #calendar {
      background: var(--card-bg);
      border-radius: 16px;
      box-shadow: var(--shadow);
      padding: 1.5rem;
      border: 1px solid var(--border-color);
    }

    /* FullCalendar Custom Styling */
    .fc {
      --fc-border-color: rgba(255, 255, 255, 0.1);
      --fc-button-bg-color: #5d9cec;
      --fc-button-border-color: #5d9cec;
      --fc-button-hover-bg-color: #4a89dc;
      --fc-button-hover-border-color: #4a89dc;
      --fc-button-active-bg-color: #4a89dc;
      --fc-button-active-border-color: #4a89dc;
      --fc-today-bg-color: rgba(72, 207, 173, 0.15);
    }

    .fc .fc-toolbar-title {
      color: var(--text-primary);
      font-size: 1.6rem;
      font-weight: 700;
    }

    .fc .fc-button {
      border-radius: 8px;
      padding: 0.5rem 1rem;
      font-weight: 600;
      text-transform: capitalize;
      box-shadow: 0 2px 8px rgba(93, 156, 236, 0.3);
    }

    .fc .fc-button:hover {
      box-shadow: 0 4px 12px rgba(93, 156, 236, 0.4);
    }

    .fc .fc-col-header-cell {
      background: rgba(93, 156, 236, 0.1);
      color: var(--text-primary);
      font-weight: 600;
      padding: 1rem 0.5rem;
      border-color: var(--border-color);
    }

    .fc .fc-daygrid-day {
      background: rgba(255, 255, 255, 0.03);
      transition: all 0.3s ease;
    }

    .fc .fc-daygrid-day:hover {
      background: rgba(93, 156, 236, 0.1);
      cursor: pointer;
    }

    .fc .fc-daygrid-day-number {
      color: var(--text-primary);
      padding: 0.5rem;
      font-weight: 500;
    }

    .fc .fc-daygrid-day.fc-day-today {
      background: rgba(72, 207, 173, 0.15) !important;
    }

    .fc .fc-daygrid-day.fc-day-today .fc-daygrid-day-number {
      background: var(--accent-color);
      color: white;
      border-radius: 50%;
      width: 32px;
      height: 32px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 700;
    }

    .fc-event {
      background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)) !important;
      border: none !important;
      border-radius: 6px;
      padding: 2px 6px;
      font-size: 0.85rem;
      font-weight: 600;
    }

    /* Modal Styles */
    .modal {
      display: none;
      position: fixed;
      z-index: 1000;
      inset: 0;
      background: rgba(0, 0, 0, 0.75);
      backdrop-filter: blur(8px);
      animation: fadeIn 0.3s ease;
    }

    .modal.active {
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .modal-content {
      background: var(--card-bg);
      margin: 2rem;
      padding: 2rem;
      border-radius: 16px;
      width: 90%;
      max-width: 700px;
      color: var(--text-primary);
      box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
      border: 1px solid var(--border-color);
      animation: slideUp 0.3s ease;
      max-height: 85vh;
      overflow-y: auto;
    }

    .modal-content h2 {
      color: var(--text-primary);
      margin-bottom: 0.5rem;
      font-size: 1.8rem;
      display: flex;
      align-items: center;
      gap: 0.75rem;
    }

    .modal-content h2 i {
      color: var(--primary-color);
    }

    #modalDate {
      color: var(--accent-color);
      font-weight: 700;
    }

    .close {
      float: right;
      font-size: 2rem;
      font-weight: 700;
      cursor: pointer;
      color: var(--text-secondary);
      transition: all 0.3s ease;
      line-height: 1;
      width: 35px;
      height: 35px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
      background: rgba(255, 255, 255, 0.05);
    }

    .close:hover {
      color: var(--primary-color);
      background: rgba(93, 156, 236, 0.15);
      transform: rotate(90deg);
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 1.5rem;
      border-radius: 12px;
      overflow: hidden;
    }

    th, td {
      border: 1px solid var(--border-color);
      padding: 1rem;
      text-align: center;
      font-size: 0.95rem;
      color: var(--text-primary);
    }

    th {
      background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
      color: white;
      font-weight: 600;
      text-transform: uppercase;
      font-size: 0.9rem;
      letter-spacing: 0.5px;
    }

    tr:nth-child(even) {
      background: rgba(255, 255, 255, 0.03);
    }

    tr:hover {
      background: rgba(93, 156, 236, 0.1);
    }

    .no-booking {
      text-align: center;
      margin: 2rem 0;
      color: var(--text-secondary);
      font-size: 1.1rem;
      padding: 2rem;
      background: rgba(255, 255, 255, 0.03);
      border-radius: 12px;
      border: 1px dashed var(--border-color);
    }

    .no-booking i {
      display: block;
      font-size: 3rem;
      color: var(--primary-color);
      margin-bottom: 1rem;
    }

    .loading {
      text-align: center;
      color: var(--text-secondary);
      padding: 2rem;
      font-size: 1.1rem;
    }

    .loading i {
      animation: spin 1s linear infinite;
      color: var(--primary-color);
      margin-right: 0.5rem;
    }

    pre.debug {
      background: rgba(0, 0, 0, 0.3);
      padding: 1rem;
      border-radius: 8px;
      overflow: auto;
      max-height: 200px;
      color: var(--accent-color);
      font-size: 0.85rem;
      border: 1px solid var(--border-color);
      margin-top: 1rem;
    }

    .error-message {
      color: #e74c3c;
      background: rgba(231, 76, 60, 0.1);
      padding: 1rem;
      border-radius: 8px;
      border: 1px solid rgba(231, 76, 60, 0.3);
      margin-top: 1rem;
    }

    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }

    @keyframes slideUp {
      from {
        opacity: 0;
        transform: translateY(30px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    @keyframes spin {
      from { transform: rotate(0deg); }
      to { transform: rotate(360deg); }
    }

    /* Responsive Design */
    @media (max-width: 768px) {
      header {
        padding: 1rem;
      }

      header h1 {
        font-size: 1.5rem;
      }

      .anchor {
        left: 1rem;
        padding: 0.6rem 0.8rem;
        font-size: 1rem;
      }

      .calendar-container {
        padding: 0 1rem;
        margin: 1rem auto;
      }

      #calendar {
        padding: 1rem;
      }

      .fc .fc-toolbar-title {
        font-size: 1.3rem;
      }

      .modal-content {
        padding: 1.5rem;
        margin: 1rem;
      }

      .modal-content h2 {
        font-size: 1.4rem;
      }

      table {
        font-size: 0.85rem;
      }

      th, td {
        padding: 0.7rem 0.5rem;
      }
    }

    @media (max-width: 480px) {
      header h1 {
        font-size: 1.2rem;
      }

      .anchor {
        position: static;
        transform: none;
        margin-bottom: 1rem;
        display: inline-flex;
      }

      header {
        padding: 1rem;
        display: flex;
        flex-direction: column;
        gap: 1rem;
      }

      .fc .fc-toolbar {
        flex-direction: column;
        gap: 0.5rem;
      }

      th, td {
        padding: 0.5rem 0.3rem;
        font-size: 0.8rem;
      }
    }
  </style>
</head>
<body>
  <header>
    <a href="index.php" class="anchor">
      <i class="fas fa-arrow-left"></i> Back
    </a>  
    <h1>
      <i class="fas fa-calendar-check"></i>
      View Court Bookings
    </h1>
  </header>

  <div class="calendar-container">
    <div id="calendar"></div>
  </div>

  <div id="dateModal" class="modal" aria-hidden="true">
    <div class="modal-content" role="dialog" aria-modal="true">
      <span class="close" title="Close">&times;</span>
      <h2>
        <i class="fas fa-calendar-day"></i>
        Bookings on <span id="modalDate"></span>
      </h2>
      <div id="bookingList"></div>
      <div id="debugInfo"></div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.15/index.global.min.js"></script>
  <script>
  document.addEventListener('DOMContentLoaded', function () {
    const calendarEl = document.getElementById('calendar');
    const modal = document.getElementById('dateModal');
    const closeBtn = document.querySelector('.close');
    const modalDate = document.getElementById('modalDate');
    const bookingList = document.getElementById('bookingList');
    const debugInfo = document.getElementById('debugInfo');

    const fetchPath = 'user/fetch_bookings.php';

    const calendar = new FullCalendar.Calendar(calendarEl, {
      initialView: 'dayGridMonth',
      events: fetchPath,
      headerToolbar: {
        left: 'prev,next today',
        center: 'title',
        right: 'dayGridMonth,dayGridWeek'
      },
      dateClick: function(info) {
        modalDate.textContent = new Date(info.dateStr).toLocaleDateString(undefined, {
          weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'
        });
        bookingList.innerHTML = "<p class='loading'><i class='fas fa-spinner'></i>Loading bookings...</p>";
        debugInfo.innerHTML = "";

        fetch(fetchPath + '?date=' + encodeURIComponent(info.dateStr), {
          credentials: 'same-origin'
        })
        .then(async res => {
          const text = await res.text();
          try {
            const data = JSON.parse(text);
            return { ok: res.ok, data };
          } catch (e) {
            throw new Error('Invalid JSON response from server: ' + text);
          }
        })
        .then(({ ok, data }) => {
          if (!ok) throw new Error('Server error: ' + JSON.stringify(data));
          if (!Array.isArray(data) || data.length === 0) {
            bookingList.innerHTML = `
              <p class='no-booking'>
                <i class='fas fa-calendar-times'></i>
                No bookings for this date.
              </p>`;
            return;
          }
          let table = `<table>
            <thead>
              <tr>
                <th><i class='fas fa-basketball-ball'></i> Court</th>
                <th><i class='fas fa-clock'></i> Time</th>
                <th><i class='fas fa-info-circle'></i> Status</th>
              </tr>
            </thead>
            <tbody>`;
          data.forEach(r => {
            const court = r.court_type ?? r.court ?? '-';
            const time = r.time ?? r.time_slot ?? '-';
            const status = r.status ?? '-';
            table += `<tr>
              <td>${escapeHtml(court)}</td>
              <td>${escapeHtml(time)}</td>
              <td>${escapeHtml(status)}</td>
            </tr>`;
          });
          table += `</tbody></table>`;
          bookingList.innerHTML = table;
        })
        .catch(err => {
          bookingList.innerHTML = `
            <p class='error-message'>
              <i class='fas fa-exclamation-triangle'></i>
              Failed to load bookings. Please try again.
            </p>`;
          debugInfo.innerHTML = "<pre class='debug'>Error: " + escapeHtml(err.message) + "</pre>";
          console.error(err);
        });

        modal.classList.add('active');
      }
    });

    calendar.render();

    closeBtn.onclick = () => modal.classList.remove('active');
    window.onclick = (e) => { 
      if (e.target === modal) modal.classList.remove('active'); 
    };

    function escapeHtml(s) {
      return String(s)
        .replaceAll('&','&amp;')
        .replaceAll('<','&lt;')
        .replaceAll('>','&gt;')
        .replaceAll('"','&quot;')
        .replaceAll("'",'&#039;');
    }
  });
  </script>
</body>
</html>