<?php
session_start();
include "../db_connect.php";

if (!isset($_SESSION['username'])) {
    http_response_code(401);
    echo "Unauthorized";
    exit;
}

// Check if a file was uploaded
if (isset($_FILES['profile_pic']) && $_FILES['profile_pic']['error'] === UPLOAD_ERR_OK) {
    $fileTmpPath = $_FILES['profile_pic']['tmp_name'];
    $fileName = $_FILES['profile_pic']['name'];
    $fileSize = $_FILES['profile_pic']['size'];
    $fileType = $_FILES['profile_pic']['type'];

    // Only allow image types
    $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    if (!in_array($fileType, $allowedTypes)) {
        http_response_code(400);
        echo "Invalid file type. Only JPG, PNG, GIF, WEBP allowed.";
        exit;
    }

    // Folder to store profile pics
    $uploadDir = '../assets/imgs/profile_pics/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }

    // Generate unique file name
    $ext = pathinfo($fileName, PATHINFO_EXTENSION);
    $newFileName = $_SESSION['username'] . '_' . time() . '.' . $ext;
    $destPath = $uploadDir . $newFileName;

    // Move the file
    if (move_uploaded_file($fileTmpPath, $destPath)) {
        // Update database
        $stmt = $conn->prepare("UPDATE users SET profile_pic = ? WHERE username = ?");
        $stmt->bind_param("ss", $newFileName, $_SESSION['username']);
        if ($stmt->execute()) {
            $_SESSION['profile_pic'] = $destPath;
            echo "Profile picture updated successfully";
        } else {
            http_response_code(500);
            echo "Database update failed";
        }
    } else {
        http_response_code(500);
        echo "File upload failed";
    }
} else {
    http_response_code(400);
    echo "No file uploaded or upload error";
}
?>
