<?php
// fetch_bookings.php
// Returns JSON:
//  - ?date=YYYY-MM-DD => [{ fullname, court_type, time, status }, ...]
//  - otherwise => FullCalendar event array for highlighting booked dates

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$included = false;
$paths = [
    __DIR__ . '/db_connect.php',
    __DIR__ . '/../db_connect.php',
    __DIR__ . '/user/db_connect.php',
];
foreach ($paths as $p) {
    if (file_exists($p)) { include_once $p; $included = true; break; }
}
if (!$included) {
    header('Content-Type: application/json; charset=utf-8', true, 500);
    echo json_encode(['error' => 'db_connect.php not found']);
    exit;
}

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$conn->set_charset('utf8mb4');

header('Content-Type: application/json; charset=utf-8');

try {
    $isLoggedIn = isset($_SESSION['username']) && !empty($_SESSION['username']);
    if (isset($_GET['date']) && $_GET['date'] !== '') {
        $date = $_GET['date'];

        $d = DateTime::createFromFormat('Y-m-d', $date);
        if (!$d || $d->format('Y-m-d') !== $date) {
            echo json_encode([]);
            exit;
        }

        $sql = "
            SELECT fullname, court_type, time_slot AS time, status
            FROM reservations
            WHERE `date` = ?

            UNION ALL

            SELECT fullname, court_type, time_slot AS time, 'ACCEPTED' AS status
            FROM accepted_bookings
            WHERE `date` = ?

            ORDER BY time
        ";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $date, $date);
        $stmt->execute();
        $res = $stmt->get_result();

        $out = [];
        while ($row = $res->fetch_assoc()) {
            if (!$isLoggedIn) {
                $row['fullname'] = "Login to view";
            }
            $out[] = $row;
        }

        echo json_encode($out);
        exit;
    }

    /* calendar forp pending and accepted bookings */
    $sql = "
        SELECT `date`, COUNT(*) AS total FROM (
            SELECT `date` FROM reservations WHERE status = 'PENDING'
            UNION ALL
            SELECT `date` FROM accepted_bookings
        ) AS combined
        GROUP BY `date`
    ";

    $res = $conn->query($sql);

    $events = [];
    while ($r = $res->fetch_assoc()) {
        $events[] = [
            'title'   => $r['total'] . ' booking(s)',
            'start'   => $r['date'],
            'allDay'  => true,
            'display' => 'background',
            'color'   => '#ff6b35'
        ];
    }

    echo json_encode($events);

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['error' => true, 'message' => $e->getMessage()]);
    error_log("fetch_bookings.php error: " . $e->getMessage());
}
