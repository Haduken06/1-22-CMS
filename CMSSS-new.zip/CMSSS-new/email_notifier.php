<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require __DIR__ . '/PHPMailer/src/Exception.php';
require __DIR__ . '/PHPMailer/src/PHPMailer.php';
require __DIR__ . '/PHPMailer/src/SMTP.php';

function sendReservationEmail($email, $fullname, $status, $row)
{
    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'reservationcourt@gmail.com';
        $mail->Password   = 'mwbc xcro ghwn xoij'; 
        $mail->SMTPSecure = 'tls';
        $mail->Port       = 587;

        $mail->setFrom('reservationcourt@gmail.com', 'Court Reservation System');
        $mail->addAddress($email, $fullname);

        $mail->isHTML(true);
        $mail->Subject = "Reservation {$status}";

        $mail->Body = "
            <h3>Hello {$fullname},</h3>
            <p>Your reservation has been <b>{$status}</b>.</p>
            <hr>
            <p><b>Details:</b></p>
            <ul>
                <li>Court: {$row['court_type']}</li>
                <li>Date: {$row['date']}</li>
                <li>Time: {$row['time_slot']}</li>
            </ul>
        ";

        $mail->send();
    } catch (Exception $e) {
        
    }
}
